export declare class LookupTableEventMessage {
    eventName: string;
    firmReference: string;
    itemType: string;
}
//# sourceMappingURL=LookupTableEventMessage.d.ts.map