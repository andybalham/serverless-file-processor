import { SQSEvent } from 'aws-lambda/trigger/sqs';
export declare const handle: (event: SQSEvent) => Promise<any>;
//# sourceMappingURL=iteratorUpdateProcessorLambda.d.ts.map