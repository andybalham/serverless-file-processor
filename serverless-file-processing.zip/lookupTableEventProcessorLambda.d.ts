import { DynamoDBStreamEvent } from 'aws-lambda';
export declare const handle: (event: DynamoDBStreamEvent) => Promise<any>;
//# sourceMappingURL=lookupTableEventProcessorLambda.d.ts.map