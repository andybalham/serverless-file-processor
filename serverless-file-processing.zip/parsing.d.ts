export declare function parseLine(line: string, expectedPartCount?: number): string[];
//# sourceMappingURL=parsing.d.ts.map