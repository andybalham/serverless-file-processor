"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.IteratorTableItem = void 0;
class IteratorTableItem {
}
exports.IteratorTableItem = IteratorTableItem;
//# sourceMappingURL=IteratorTableItems.js.map