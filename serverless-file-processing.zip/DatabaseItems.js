"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.FirmAppointedRepresentativeDatabaseItem = exports.FirmPrincipalDatabaseItem = exports.FirmPermission = exports.FirmPermissionsDatabaseItem = exports.AlternativeFirmName = exports.AlternativeFirmNamesDatabaseItem = exports.FirmAuthorisationDatabaseItem = exports.DatabaseItem = void 0;
const object_hash_1 = __importDefault(require("object-hash"));
class DatabaseItem {
    static getItemHash(item) {
        return object_hash_1.default(item, { unorderedArrays: true });
    }
}
exports.DatabaseItem = DatabaseItem;
class FirmAuthorisationDatabaseItem extends DatabaseItem {
}
exports.FirmAuthorisationDatabaseItem = FirmAuthorisationDatabaseItem;
class AlternativeFirmNamesDatabaseItem extends DatabaseItem {
}
exports.AlternativeFirmNamesDatabaseItem = AlternativeFirmNamesDatabaseItem;
class AlternativeFirmName {
}
exports.AlternativeFirmName = AlternativeFirmName;
class FirmPermissionsDatabaseItem extends DatabaseItem {
}
exports.FirmPermissionsDatabaseItem = FirmPermissionsDatabaseItem;
class FirmPermission {
}
exports.FirmPermission = FirmPermission;
class FirmPrincipalDatabaseItem extends DatabaseItem {
}
exports.FirmPrincipalDatabaseItem = FirmPrincipalDatabaseItem;
class FirmAppointedRepresentativeDatabaseItem extends DatabaseItem {
}
exports.FirmAppointedRepresentativeDatabaseItem = FirmAppointedRepresentativeDatabaseItem;
//# sourceMappingURL=DatabaseItems.js.map