import { SQSEvent } from 'aws-lambda/trigger/sqs';
import { UpdateMessage } from './UpdateMessage';
import { DatabaseItem } from './DatabaseItems';
export declare const handle: (event: SQSEvent) => Promise<any>;
export declare function processUpdateMessage(updateMessage: UpdateMessage, updater: (databaseItems: DatabaseItem[]) => Promise<void>): Promise<void>;
//# sourceMappingURL=updateProcessorLambda.d.ts.map