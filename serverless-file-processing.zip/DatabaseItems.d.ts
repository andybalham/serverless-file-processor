export interface IDatabaseItemKeys {
    firmReference: string;
    itemType: string;
}
export declare abstract class DatabaseItem implements IDatabaseItemKeys {
    firmReference: string;
    itemType: string;
    itemHash?: string;
    static getItemHash(item: DatabaseItem): string;
}
export declare class FirmAuthorisationDatabaseItem extends DatabaseItem {
    registeredFirmName: string;
    addressLine1?: string;
    addressLine2?: string;
    addressLine3?: string;
    addressLine4?: string;
    addressLine5?: string;
    addressLine6?: string;
    postcodeIn?: string;
    postcodeOut?: string;
    currentAuthorisationStatusCode: string;
}
export declare class AlternativeFirmNamesDatabaseItem extends DatabaseItem {
    names: AlternativeFirmName[];
}
export declare class AlternativeFirmName {
    name: string;
    effectiveDate: string;
    endDate?: string;
}
export declare class FirmPermissionsDatabaseItem extends DatabaseItem {
    regulatedActivityCode: string;
    permissions: FirmPermission[];
}
export declare class FirmPermission {
    investmentTypeCode?: string;
    customerTypeCode?: string;
    statusCode: string;
    effectiveDate: string;
}
export declare class FirmPrincipalDatabaseItem extends DatabaseItem {
    principalFirmRef: string;
    statusCode: string;
    statusEffectiveDate: string;
}
export declare class FirmAppointedRepresentativeDatabaseItem extends DatabaseItem {
    appointedRepresentativeFirmRef: string;
    statusCode: string;
    statusEffectiveDate: string;
}
//# sourceMappingURL=DatabaseItems.d.ts.map