export declare class IteratorTableItem {
    iteratorType: string;
    sortKey: string;
}
//# sourceMappingURL=IteratorTableItems.d.ts.map