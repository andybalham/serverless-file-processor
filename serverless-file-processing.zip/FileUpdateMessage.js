"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FileUpdateMessage = void 0;
class FileUpdateMessage {
}
exports.FileUpdateMessage = FileUpdateMessage;
//# sourceMappingURL=FileUpdateMessage.js.map