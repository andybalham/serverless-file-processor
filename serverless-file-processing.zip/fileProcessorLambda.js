"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.processFileStream = exports.handle = void 0;
const readline_1 = __importDefault(require("readline"));
const aws_sdk_1 = require("aws-sdk");
const sqs_1 = __importDefault(require("aws-sdk/clients/sqs"));
const parsing_1 = require("./parsing");
const FileType_1 = require("./FileType");
const s3Client = new aws_sdk_1.S3;
const sqsClient = new sqs_1.default;
exports.handle = (event) => __awaiter(void 0, void 0, void 0, function* () {
    console.log(`event: ${JSON.stringify(event)}`);
    for (let sqsEventRecordIndex = 0; sqsEventRecordIndex < event.Records.length; sqsEventRecordIndex++) {
        const sqsEventRecord = event.Records[sqsEventRecordIndex];
        const s3Event = JSON.parse(sqsEventRecord.body);
        const handleUpdate = (fileHeaderLine, updateLines) => __awaiter(void 0, void 0, void 0, function* () {
            var _a;
            const message = {
                headerLine: fileHeaderLine,
                dataLines: updateLines
            };
            const params = {
                MessageBody: JSON.stringify(message),
                QueueUrl: (_a = process.env.UNPROCESSED_UPDATE_QUEUE_URL) !== null && _a !== void 0 ? _a : 'undefined'
            };
            console.log(`Sending: ${JSON.stringify(params)}`);
            const result = yield sqsClient.sendMessage(params).promise();
            console.log(`result: ${JSON.stringify(result)}`);
        });
        if ('Records' in s3Event) {
            for (let s3EventRecordIndex = 0; s3EventRecordIndex < s3Event.Records.length; s3EventRecordIndex++) {
                const s3EventRecord = s3Event.Records[s3EventRecordIndex];
                if (s3EventRecord.eventName === 'ObjectCreated:Put') {
                    const bucket = s3EventRecord.s3.bucket.name;
                    const key = decodeURIComponent(s3EventRecord.s3.object.key.replace(/\+/g, ' '));
                    const params = {
                        Bucket: bucket,
                        Key: key,
                    };
                    console.log(`params: ${JSON.stringify(params)}`);
                    const s3ReadStream = s3Client.getObject(params).createReadStream();
                    yield processFileStream(s3ReadStream, handleUpdate);
                    console.log('Processed file stream');
                }
                else {
                    console.warn(`Unexpected eventName: ${s3EventRecord.eventName}`);
                }
            }
        }
        else {
            console.log('Test event received');
        }
    }
    console.log('Exiting');
});
class TestEvent {
}
function processFileStream(readerStream, handleLineGroup) {
    return __awaiter(this, void 0, void 0, function* () {
        let fileType = undefined;
        let fileHeaderLine = '';
        let currentLineKey = null;
        let currentLineGroup = new Array();
        const getLineKey = (lineParts) => {
            switch (fileType) {
                case FileType_1.FileType.Appointment:
                case FileType_1.FileType.FirmPermission:
                    return `${lineParts[0]}|${lineParts[1]}`;
                default:
                    return lineParts[0];
            }
        };
        // TODO 25Aug20: Consider
        // try {
        //     const rl = createInterface({
        //       input: createReadStream('big-file.txt'),
        //       crlfDelay: Infinity
        //     });
        //     rl.on('line', (line) => {
        //       // Process the line.
        //     });
        //     await once(rl, 'close');
        //     console.log('File processed.');
        //   } catch (err) {
        //     console.error(err);
        //   }
        const readFileAsync = new Promise((resolve, reject) => {
            const lineReader = readline_1.default
                .createInterface({
                input: readerStream,
                terminal: false
            });
            lineReader.on('line', (line) => __awaiter(this, void 0, void 0, function* () {
                const lineParts = parsing_1.parseLine(line);
                if (lineParts[0] === 'Header') {
                    fileType = lineParts[1];
                    fileHeaderLine = line;
                    return;
                }
                if (lineParts[0] === 'Footer') {
                    return;
                }
                const lineKey = getLineKey(lineParts);
                if (lineKey === currentLineKey) {
                    currentLineGroup.push(line);
                }
                else {
                    const previousLineGroup = currentLineGroup;
                    currentLineKey = lineKey;
                    currentLineGroup = [line];
                    if (previousLineGroup.length > 0) {
                        yield handleLineGroup(fileHeaderLine, previousLineGroup);
                    }
                }
            }));
            lineReader.on('close', () => __awaiter(this, void 0, void 0, function* () {
                console.log('closed');
                if (currentLineGroup.length > 0) {
                    yield handleLineGroup(fileHeaderLine, currentLineGroup);
                }
                resolve();
            }));
        });
        try {
            yield readFileAsync;
        }
        catch (err) {
            console.log('an error has occurred');
        }
        console.log('done reading!');
    });
}
exports.processFileStream = processFileStream;
//# sourceMappingURL=fileProcessorLambda.js.map