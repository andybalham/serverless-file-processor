"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.handle = void 0;
const aws_sdk_1 = require("aws-sdk");
const sns_1 = __importDefault(require("aws-sdk/clients/sns"));
const snsClient = new sns_1.default;
exports.handle = (event) => __awaiter(void 0, void 0, void 0, function* () {
    var _a;
    console.log(`event: ${JSON.stringify(event)}`);
    for (let index = 0; index < event.Records.length; index++) {
        const record = event.Records[index];
        if ((record.eventName !== undefined)
            && (record.dynamodb !== undefined)
            && (((_a = record.dynamodb) === null || _a === void 0 ? void 0 : _a.Keys) !== undefined)) {
            const eventName = record.eventName;
            const eventKeys = aws_sdk_1.DynamoDB.Converter.unmarshall(record.dynamodb.Keys);
            // const oldImage = 
            //     record.dynamodb.OldImage === undefined 
            //         ? undefined
            //         : DynamoDB.Converter.unmarshall(record.dynamodb.OldImage) as DatabaseItem;
            // const newImage = 
            //     record.dynamodb.NewImage === undefined
            //         ? undefined
            //         : DynamoDB.Converter.unmarshall(record.dynamodb.NewImage) as DatabaseItem;
            yield processEventRecord(eventName, eventKeys /*, oldImage, newImage*/);
        }
    }
});
function processEventRecord(eventName, eventKeys /*,
    oldImage?: DatabaseItem, newImage?: DatabaseItem*/) {
    return __awaiter(this, void 0, void 0, function* () {
        if (eventName === 'REMOVE') {
            // Ignore remove events
            return;
        }
        const eventMessage = {
            eventName: eventName,
            firmReference: eventKeys.firmReference,
            itemType: eventKeys.itemType,
        };
        const publishInput = {
            Message: JSON.stringify(eventMessage),
            TopicArn: process.env.LOOKUP_TABLE_EVENT_TOPIC,
            MessageAttributes: {
                EventName: { DataType: 'String', StringValue: eventName },
                FirmReference: { DataType: 'String', StringValue: eventKeys.firmReference },
                ItemType: { DataType: 'String', StringValue: eventKeys.itemType },
            }
        };
        console.log(`publishInput: ${JSON.stringify(publishInput)}`);
        const publishResponse = yield snsClient.publish(publishInput).promise();
        console.log(`publishResponse: ${JSON.stringify(publishResponse)}`);
    });
}
//# sourceMappingURL=lookupTableEventProcessorLambda.js.map