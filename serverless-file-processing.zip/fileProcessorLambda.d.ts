/// <reference types="node" />
import { Readable } from 'stream';
import { SQSEvent } from 'aws-lambda/trigger/sqs';
export declare const handle: (event: SQSEvent) => Promise<any>;
export declare function processFileStream(readerStream: Readable, handleLineGroup: (fileHeaderLine: string, lineGroup: string[]) => Promise<void>): Promise<void>;
//# sourceMappingURL=fileProcessorLambda.d.ts.map