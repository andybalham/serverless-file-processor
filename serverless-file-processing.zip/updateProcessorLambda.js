"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.processUpdateMessage = exports.handle = void 0;
const FileType_1 = require("./FileType");
const DatabaseItems_1 = require("./DatabaseItems");
const dynamodb_1 = __importDefault(require("aws-sdk/clients/dynamodb"));
const parsing_1 = require("./parsing");
exports.handle = (event) => __awaiter(void 0, void 0, void 0, function* () {
    console.log(`event: ${JSON.stringify(event)}`);
    for (let recordIndex = 0; recordIndex < event.Records.length; recordIndex++) {
        const sqsEventRecord = event.Records[recordIndex];
        const updateMessage = JSON.parse(sqsEventRecord.body);
        yield processUpdateMessage(updateMessage, updateDatabase);
        console.log(`sqsEventRecord: ${JSON.stringify(sqsEventRecord)}`);
    }
    console.log('Exiting');
});
const dynamoDbClient = new dynamodb_1.default.DocumentClient();
function updateDatabase(databaseItems) {
    return __awaiter(this, void 0, void 0, function* () {
        // https://docs.aws.amazon.com/AWSJavaScriptSDK/latest/AWS/DynamoDB/DocumentClient.html#transactWrite-property
        // https://www.alexdebrie.com/posts/dynamodb-transactions/
        // https://docs.aws.amazon.com/amazondynamodb/latest/APIReference/API_TransactWriteItems.html
        if (process.env.TARGET_TABLE_NAME === undefined)
            throw new Error('process.env.TARGET_TABLE_NAME === undefined');
        // TODO 19Sep20: Avoid using transactions for single updates
        const putItems = databaseItems.map(item => {
            var _a;
            return {
                Put: {
                    TableName: (_a = process.env.TARGET_TABLE_NAME) !== null && _a !== void 0 ? _a : '',
                    Item: item,
                    ConditionExpression: 'itemHash <> :itemHash',
                    ExpressionAttributeValues: { ':itemHash': item.itemHash },
                    ReturnValuesOnConditionCheckFailure: 'NONE'
                }
            };
        });
        const params = {
            TransactItems: putItems
        };
        try {
            yield dynamoDbClient.transactWrite(params).promise();
        }
        catch (error) {
            if (error instanceof Error) {
                console.log(`error.message: ${error.message}`);
                if (!error.message.includes('ConditionalCheckFailed')) {
                    console.error('TODO: How should we handle this error?');
                    // throw error;
                }
            }
            else {
                throw error;
            }
        }
        // console.log(`databaseItems: ${JSON.stringify(databaseItems)}`);
    });
}
function processUpdateMessage(updateMessage, updater) {
    return __awaiter(this, void 0, void 0, function* () {
        const databaseItems = getDatabaseItems(updateMessage);
        yield updater(databaseItems);
    });
}
exports.processUpdateMessage = processUpdateMessage;
function getDatabaseItems(updateMessage) {
    const fileType = updateMessage.headerLine.split('|')[1];
    // TODO 12Sep20: How can we reject the message if we are not able to process it?
    let databaseItems;
    switch (fileType) {
        case FileType_1.FileType.FirmsMasterList:
            databaseItems = getFirmsMasterListDatabaseItems(updateMessage);
            break;
        case FileType_1.FileType.AlternativeFirmName:
            databaseItems = getAlternativeFirmNameDatabaseItems(updateMessage);
            break;
        case FileType_1.FileType.FirmPermission:
            databaseItems = getFirmPermissionDatabaseItems(updateMessage);
            break;
        case FileType_1.FileType.Appointment:
            databaseItems = getAppointmentDatabaseItems(updateMessage);
            break;
        default:
            throw new Error(`Unhandled file type: ${fileType}`);
    }
    console.log(`${fileType},${JSON.stringify(databaseItems)}`);
    return databaseItems;
}
function getAppointmentDatabaseItems(updateMessage) {
    const dataValuesArray = updateMessage.dataLines.map(line => parsing_1.parseLine(line, 9));
    const appointmentDataValues = dataValuesArray[0];
    const firmAppointedRepresentative = {
        firmReference: appointmentDataValues[0],
        itemType: `FirmPrincipal-${appointmentDataValues[1]}`,
        principalFirmRef: appointmentDataValues[1],
        statusCode: appointmentDataValues[2],
        statusEffectiveDate: getDateItemValue(appointmentDataValues[3]),
    };
    firmAppointedRepresentative.itemHash = DatabaseItems_1.DatabaseItem.getItemHash(firmAppointedRepresentative);
    const firmPrincipal = {
        firmReference: appointmentDataValues[1],
        itemType: `FirmAppointedRepresentative-${appointmentDataValues[0]}`,
        appointedRepresentativeFirmRef: appointmentDataValues[0],
        statusCode: firmAppointedRepresentative.statusCode,
        statusEffectiveDate: firmAppointedRepresentative.statusEffectiveDate,
    };
    firmPrincipal.itemHash = DatabaseItems_1.DatabaseItem.getItemHash(firmPrincipal);
    return [firmAppointedRepresentative, firmPrincipal];
}
function getFirmPermissionDatabaseItems(updateMessage) {
    const dataValuesArray = updateMessage.dataLines.map(line => parsing_1.parseLine(line, 8));
    const getFirmPermissions = (dataValuesArray) => dataValuesArray.map(firmPermissionValues => {
        return {
            investmentTypeCode: getStringItemValue(firmPermissionValues[2]),
            customerTypeCode: getStringItemValue(firmPermissionValues[3]),
            statusCode: firmPermissionValues[4],
            effectiveDate: getDateItemValue(firmPermissionValues[5]),
        };
    });
    const firmPermissionsDatabaseItem = {
        firmReference: dataValuesArray[0][0],
        itemType: `RegulatedActivityPermissions-${dataValuesArray[0][1]}`,
        regulatedActivityCode: dataValuesArray[0][1],
        permissions: getFirmPermissions(dataValuesArray)
    };
    firmPermissionsDatabaseItem.itemHash = DatabaseItems_1.DatabaseItem.getItemHash(firmPermissionsDatabaseItem);
    return [firmPermissionsDatabaseItem];
}
function getAlternativeFirmNameDatabaseItems(updateMessage) {
    const dataValuesArray = updateMessage.dataLines.map(line => parsing_1.parseLine(line, 8));
    const getAlternativeNames = (dataValuesArray) => dataValuesArray.map(alternativeNameValues => {
        return {
            name: alternativeNameValues[1],
            effectiveDate: getDateItemValue(alternativeNameValues[3]),
            endDate: getOptionalDateItemValue(alternativeNameValues[4]),
        };
    });
    const alternativeNamesDatabaseItem = {
        firmReference: dataValuesArray[0][0],
        itemType: 'AlternativeFirmNames',
        names: getAlternativeNames(dataValuesArray)
    };
    alternativeNamesDatabaseItem.itemHash = DatabaseItems_1.DatabaseItem.getItemHash(alternativeNamesDatabaseItem);
    return [alternativeNamesDatabaseItem];
}
function getDateItemValue(dateString) {
    const formattedDateString = `${dateString.slice(0, 4)}-${dateString.slice(4, 6)}-${dateString.slice(6, 8)}`;
    return formattedDateString;
}
function getOptionalDateItemValue(dateString) {
    return (dateString === '') ? undefined : getDateItemValue(dateString);
}
function getFirmsMasterListDatabaseItems(updateMessage) {
    const dataValuesArray = updateMessage.dataLines.map(line => parsing_1.parseLine(line, 29));
    const firmAuthorisationValues = dataValuesArray[0];
    const firmAuthorisationDatabaseItem = {
        firmReference: firmAuthorisationValues[0],
        itemType: 'FirmAuthorisation',
        registeredFirmName: firmAuthorisationValues[1],
        addressLine1: getStringItemValue(firmAuthorisationValues[5]),
        addressLine2: getStringItemValue(firmAuthorisationValues[6]),
        addressLine3: getStringItemValue(firmAuthorisationValues[7]),
        addressLine4: getStringItemValue(firmAuthorisationValues[8]),
        addressLine5: getStringItemValue(firmAuthorisationValues[9]),
        addressLine6: getStringItemValue(firmAuthorisationValues[10]),
        postcodeIn: getStringItemValue(firmAuthorisationValues[11]),
        postcodeOut: getStringItemValue(firmAuthorisationValues[12]),
        currentAuthorisationStatusCode: firmAuthorisationValues[19],
    };
    firmAuthorisationDatabaseItem.itemHash = DatabaseItems_1.DatabaseItem.getItemHash(firmAuthorisationDatabaseItem);
    return [firmAuthorisationDatabaseItem];
}
function getStringItemValue(fileValue) {
    return fileValue === '' ? undefined : fileValue;
}
//# sourceMappingURL=updateProcessorLambda.js.map