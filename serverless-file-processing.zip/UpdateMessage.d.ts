export declare class UpdateMessage {
    headerLine: string;
    dataLines: string[];
}
//# sourceMappingURL=UpdateMessage.d.ts.map