"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.FirmAppointedRepresentativeLookupTableItem = exports.FirmPrincipalLookupTableItem = exports.FirmPermission = exports.FirmPermissionsLookupTableItem = exports.AlternativeFirmName = exports.AlternativeFirmNamesLookupTableItem = exports.FirmAuthorisationLookupTableItem = exports.LookupTableItem = void 0;
const object_hash_1 = __importDefault(require("object-hash"));
class LookupTableItem {
    static getItemHash(item) {
        return object_hash_1.default(item, { unorderedArrays: true });
    }
}
exports.LookupTableItem = LookupTableItem;
class FirmAuthorisationLookupTableItem extends LookupTableItem {
}
exports.FirmAuthorisationLookupTableItem = FirmAuthorisationLookupTableItem;
class AlternativeFirmNamesLookupTableItem extends LookupTableItem {
}
exports.AlternativeFirmNamesLookupTableItem = AlternativeFirmNamesLookupTableItem;
class AlternativeFirmName {
}
exports.AlternativeFirmName = AlternativeFirmName;
class FirmPermissionsLookupTableItem extends LookupTableItem {
}
exports.FirmPermissionsLookupTableItem = FirmPermissionsLookupTableItem;
class FirmPermission {
}
exports.FirmPermission = FirmPermission;
class FirmPrincipalLookupTableItem extends LookupTableItem {
}
exports.FirmPrincipalLookupTableItem = FirmPrincipalLookupTableItem;
class FirmAppointedRepresentativeLookupTableItem extends LookupTableItem {
}
exports.FirmAppointedRepresentativeLookupTableItem = FirmAppointedRepresentativeLookupTableItem;
//# sourceMappingURL=LookupTableItems.js.map