"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.handle = void 0;
const dynamodb_1 = __importDefault(require("aws-sdk/clients/dynamodb"));
const dynamoDbClient = new dynamodb_1.default.DocumentClient();
exports.handle = (event) => __awaiter(void 0, void 0, void 0, function* () {
    var _a, _b, _c;
    console.log(`event: ${JSON.stringify(event)}`);
    for (let recordIndex = 0; recordIndex < event.Records.length; recordIndex++) {
        const sqsEventRecord = event.Records[recordIndex];
        const snsMessage = JSON.parse(sqsEventRecord.body);
        const lookupTableEventMessage = JSON.parse(snsMessage.Message);
        console.log(`lookupTableEventMessage: ${JSON.stringify(lookupTableEventMessage)}`);
        /*
            AlternativeFirmNames
            `FirmPrincipal-${appointmentDataValues[1]}`
            `RegulatedActivityPermissions-${dataValuesArray[0][1]}`
        */
        const itemTypeMatch = lookupTableEventMessage.itemType.match(/^(?<iteratorType>(FirmAuthorisation|AlternativeFirmNames|FirmPrincipal|RegulatedActivityPermissions))(-(?<sortKeySuffix>.*))?$/);
        if (itemTypeMatch === null) {
            throw new Error(`Cannot match itemType: ${lookupTableEventMessage.itemType}`);
        }
        // TODO 20Sep20: Assumes firmReference is always the same length, we also need to pad activity code as well
        const sortKey = ((_a = itemTypeMatch.groups) === null || _a === void 0 ? void 0 : _a.sortKeySuffix) === undefined
            ? lookupTableEventMessage.firmReference
            : `${lookupTableEventMessage.firmReference}-${(_b = itemTypeMatch.groups) === null || _b === void 0 ? void 0 : _b.sortKeySuffix}`;
        const params = {
            TableName: process.env.TARGET_TABLE_NAME,
            Item: {
                iteratorType: (_c = itemTypeMatch.groups) === null || _c === void 0 ? void 0 : _c.iteratorType,
                sortKey: sortKey,
                aloha: 'from Hawaii'
            }
        };
        yield dynamoDbClient.put(params).promise();
    }
    console.log('Exiting');
});
//# sourceMappingURL=iteratorUpdateProcessorLambda.js.map