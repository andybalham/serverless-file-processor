export declare const handle: (event: any) => Promise<any>;
//# sourceMappingURL=eventProcessorLambda.d.ts.map