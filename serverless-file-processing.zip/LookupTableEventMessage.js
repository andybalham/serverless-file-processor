"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.LookupTableEventMessage = void 0;
class LookupTableEventMessage {
}
exports.LookupTableEventMessage = LookupTableEventMessage;
//# sourceMappingURL=LookupTableEventMessage.js.map