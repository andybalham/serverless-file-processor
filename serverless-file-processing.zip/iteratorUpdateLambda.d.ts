import { SQSEvent } from 'aws-lambda/trigger/sqs';
import { IteratorUpdateMessage } from './IteratorUpdateMessage';
import { DatabaseItem } from './DatabaseItems';
export declare const handle: (event: SQSEvent) => Promise<any>;
export declare function processUpdateMessage(updateMessage: IteratorUpdateMessage, updater: (databaseItems: DatabaseItem[]) => Promise<void>): Promise<void>;
//# sourceMappingURL=iteratorUpdateLambda.d.ts.map