"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UpdateMessage = void 0;
class UpdateMessage {
}
exports.UpdateMessage = UpdateMessage;
//# sourceMappingURL=UpdateMessage.js.map