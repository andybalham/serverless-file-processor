export declare class FileUpdateMessage {
    headerLine: string;
    dataLines: string[];
}
//# sourceMappingURL=FileUpdateMessage.d.ts.map