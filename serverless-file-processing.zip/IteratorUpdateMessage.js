"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.IteratorUpdateMessage = void 0;
class IteratorUpdateMessage {
}
exports.IteratorUpdateMessage = IteratorUpdateMessage;
//# sourceMappingURL=IteratorUpdateMessage.js.map