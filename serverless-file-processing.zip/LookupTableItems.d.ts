export interface ILookupTableItemKeys {
    firmReference: string;
    itemType: string;
}
export declare abstract class LookupTableItem implements ILookupTableItemKeys {
    firmReference: string;
    itemType: string;
    itemHash?: string;
    static getItemHash(item: LookupTableItem): string;
}
export declare class FirmAuthorisationLookupTableItem extends LookupTableItem {
    registeredFirmName: string;
    addressLine1?: string;
    addressLine2?: string;
    addressLine3?: string;
    addressLine4?: string;
    addressLine5?: string;
    addressLine6?: string;
    postcodeIn?: string;
    postcodeOut?: string;
    currentAuthorisationStatusCode: string;
}
export declare class AlternativeFirmNamesLookupTableItem extends LookupTableItem {
    names: AlternativeFirmName[];
}
export declare class AlternativeFirmName {
    name: string;
    effectiveDate: string;
    endDate?: string;
}
export declare class FirmPermissionsLookupTableItem extends LookupTableItem {
    regulatedActivityCode: string;
    permissions: FirmPermission[];
}
export declare class FirmPermission {
    investmentTypeCode?: string;
    customerTypeCode?: string;
    statusCode: string;
    effectiveDate: string;
}
export declare class FirmPrincipalLookupTableItem extends LookupTableItem {
    principalFirmRef: string;
    statusCode: string;
    statusEffectiveDate: string;
}
export declare class FirmAppointedRepresentativeLookupTableItem extends LookupTableItem {
    appointedRepresentativeFirmRef: string;
    statusCode: string;
    statusEffectiveDate: string;
}
//# sourceMappingURL=LookupTableItems.d.ts.map