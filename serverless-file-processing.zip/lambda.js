"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.processFileStream = exports.handle = void 0;
const readline_1 = __importDefault(require("readline"));
const aws_sdk_1 = require("aws-sdk");
const sqs_1 = __importDefault(require("aws-sdk/clients/sqs"));
const s3Client = new aws_sdk_1.S3;
const sqsClient = new sqs_1.default;
exports.handle = (event) => __awaiter(void 0, void 0, void 0, function* () {
    console.log(`event: ${JSON.stringify(event)}`);
    for (let sqsEventRecordIndex = 0; sqsEventRecordIndex < event.Records.length; sqsEventRecordIndex++) {
        const sqsEventRecord = event.Records[sqsEventRecordIndex];
        const s3Event = JSON.parse(sqsEventRecord.body);
        const handleFirmLines = (fileHeaderLine, firmLines) => __awaiter(void 0, void 0, void 0, function* () {
            var _a;
            const message = {
                fileHeader: fileHeaderLine,
                firmLines: firmLines
            };
            const params = {
                MessageBody: JSON.stringify(message),
                QueueUrl: (_a = process.env.UNPROCESSED_UPDATE_QUEUE_URL) !== null && _a !== void 0 ? _a : 'undefined'
            };
            // console.log(`Would have sent: ${JSON.stringify(params)}`);
            const result = yield sqsClient.sendMessage(params).promise();
            console.log(`result: ${JSON.stringify(result)}`);
        });
        if ('Records' in s3Event) {
            for (let s3EventRecordIndex = 0; s3EventRecordIndex < s3Event.Records.length; s3EventRecordIndex++) {
                const s3EventRecord = s3Event.Records[s3EventRecordIndex];
                if (s3EventRecord.eventName === 'ObjectCreated:Put') {
                    const bucket = s3EventRecord.s3.bucket.name;
                    const key = decodeURIComponent(s3EventRecord.s3.object.key.replace(/\+/g, ' '));
                    const params = {
                        Bucket: bucket,
                        Key: key,
                    };
                    console.log(`params: ${JSON.stringify(params)}`);
                    const s3ReadStream = s3Client.getObject(params).createReadStream();
                    yield processFileStream(s3ReadStream, handleFirmLines);
                    // const readFileAsync = new Promise((resolve, reject) => {
                    //     const lineReader = readline
                    //         .createInterface({
                    //             input: s3ReadStream,
                    //             terminal: false
                    //         });
                    //     lineReader.on('line', (line: string) => {
                    //         console.log(line);
                    //     });
                    //     lineReader.on('close', () => {
                    //         console.log('closed');
                    //         resolve();
                    //     });
                    // });
                    // await readFileAsync;
                    console.log('Processed file stream');
                }
                else {
                    console.warn(`Unexpected eventName: ${s3EventRecord.eventName}`);
                }
            }
        }
        else {
            console.log('Test event received');
        }
    }
    console.log('Exiting');
});
class TestEvent {
}
function processFileStream(readerStream, handleLineGroup) {
    return __awaiter(this, void 0, void 0, function* () {
        let fileHeaderLine = '';
        let currentLineKey = null;
        let currentLineGroup = new Array();
        const getLineKey = (line) => {
            return line.slice(0, line.indexOf('|'));
        };
        const readFileAsync = new Promise((resolve, reject) => {
            const lineReader = readline_1.default
                .createInterface({
                input: readerStream,
                terminal: false
            });
            lineReader.on('line', (line) => __awaiter(this, void 0, void 0, function* () {
                const lineKey = getLineKey(line);
                console.log(line);
                if (lineKey === 'Header') {
                    fileHeaderLine = line;
                }
                else {
                    if (lineKey === currentLineKey) {
                        currentLineGroup.push(line);
                    }
                    else {
                        const previousLineGroup = currentLineGroup;
                        currentLineKey = lineKey;
                        currentLineGroup = [line];
                        if (previousLineGroup.length > 0) {
                            yield handleLineGroup(fileHeaderLine, previousLineGroup);
                        }
                    }
                }
            }));
            lineReader.on('close', () => __awaiter(this, void 0, void 0, function* () {
                console.log('closed');
                if (currentLineGroup.length > 0) {
                    yield handleLineGroup(fileHeaderLine, currentLineGroup);
                }
                resolve();
            }));
        });
        // const readFileAsync = new Promise(resolve => {
        //     const lineReader = readline
        //         .createInterface({
        //             input: readerStream,
        //             terminal: false
        //         });
        //     lineReader.on('line', (line: string) => {
        //         console.log(line);
        //     });
        //     lineReader.on('close', () => {
        //         console.log('closed');
        //         resolve();
        //     });
        // });
        try {
            yield readFileAsync;
        }
        catch (err) {
            console.log('an error has occurred');
        }
        console.log('done reading!');
    });
}
exports.processFileStream = processFileStream;
//# sourceMappingURL=lambda.js.map