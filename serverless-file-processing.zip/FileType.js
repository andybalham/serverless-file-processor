"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FileType = void 0;
var FileType;
(function (FileType) {
    FileType["Appointment"] = "Appointment";
    FileType["FirmsMasterList"] = "Firms Master List";
    FileType["AlternativeFirmName"] = "Alternative Firm Name";
    FileType["FirmPermission"] = "Firm Permission";
})(FileType = exports.FileType || (exports.FileType = {}));
//# sourceMappingURL=FileType.js.map