import { SQSEvent } from 'aws-lambda/trigger/sqs';
import { FileUpdateMessage } from './FileUpdateMessage';
import { LookupTableItem } from './LookupTableItems';
export declare const handle: (event: SQSEvent) => Promise<any>;
export declare function processUpdateMessage(updateMessage: FileUpdateMessage, updater: (databaseItems: LookupTableItem[]) => Promise<void>): Promise<void>;
//# sourceMappingURL=fileUpdateProcessorLambda.d.ts.map