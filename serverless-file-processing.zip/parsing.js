"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.parseLine = void 0;
function parseLine(line, expectedPartCount) {
    const lineParts = line.split('|');
    if ((expectedPartCount === undefined) || (lineParts.length === expectedPartCount)) {
        return lineParts;
    }
    const mergedLineParts = mergeLineParts(lineParts);
    return mergedLineParts;
}
exports.parseLine = parseLine;
function mergeLineParts(lineParts) {
    const mergedLineParts = new Array();
    for (let index = 0; index < lineParts.length; index++) {
        const linePart = lineParts[index];
        if (!linePart.startsWith('"')) {
            mergedLineParts.push(linePart);
            continue;
        }
        const closingPartIndex = lineParts.findIndex((part, partIndex) => (partIndex > index) && part.endsWith('"'));
        if (closingPartIndex == -1) {
            mergedLineParts.push(linePart);
            continue;
        }
        const splitParts = lineParts.slice(index, closingPartIndex + 1);
        const mergedLinePart = splitParts.join('|');
        const trimmedMergedLinePart = mergedLinePart.slice(1, mergedLinePart.length - 1);
        mergedLineParts.push(trimmedMergedLinePart);
        index = closingPartIndex;
    }
    return mergedLineParts;
}
//# sourceMappingURL=parsing.js.map