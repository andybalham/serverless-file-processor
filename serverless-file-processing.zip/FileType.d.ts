export declare enum FileType {
    Appointment = "Appointment",
    FirmsMasterList = "Firms Master List",
    AlternativeFirmName = "Alternative Firm Name",
    FirmPermission = "Firm Permission"
}
//# sourceMappingURL=FileType.d.ts.map