export declare class IteratorUpdateMessage {
    headerLine: string;
    dataLines: string[];
}
//# sourceMappingURL=IteratorUpdateMessage.d.ts.map